
import React from 'react';
import { Star, Quote } from 'lucide-react';

const Reviews = () => {
  const reviews = [
    {
      name: "Sarah Johnson",
      company: "TechStartup Inc.",
      role: "CEO",
      rating: 5,
      text: "Maheswari transformed our business strategy completely. Their insights helped us increase revenue by 60% in just 8 months. Absolutely exceptional service!",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Michael Chen",
      company: "Global Manufacturing Co.",
      role: "Operations Director",
      rating: 5,
      text: "The digital transformation project exceeded all our expectations. The team's expertise in process optimization saved us over $2M annually.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Emily Rodriguez",
      company: "Retail Dynamics",
      role: "VP Strategy",
      rating: 5,
      text: "Working with Maheswari was a game-changer. Their strategic planning helped us expand to 5 new markets successfully. Highly recommend!",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "David Kim",
      company: "FinanceForward",
      role: "Founder",
      rating: 5,
      text: "The risk management framework they developed protected our company during market volatility. Their foresight and expertise are unmatched.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Lisa Thompson",
      company: "Healthcare Solutions",
      role: "CMO",
      rating: 5,
      text: "Maheswari's innovation consulting helped us launch 3 breakthrough products. Their creative approach to problem-solving is remarkable.",
      image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Robert Martinez",
      company: "EcoEnergy Corp",
      role: "President",
      rating: 5,
      text: "The performance analytics dashboard they created gave us insights we never had before. Data-driven decisions became our competitive advantage.",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face"
    }
  ];

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        size={20}
        className={index < rating ? "text-yellow-400 fill-current" : "text-gray-300"}
      />
    ));
  };

  return (
    <section id="reviews" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            What Our <span className="text-blue-600">Clients Say</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what business leaders say about working with Maheswari.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="bg-gradient-to-br from-white to-gray-50 border border-gray-200 rounded-2xl p-8 hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 relative">
              <div className="absolute top-6 right-6 text-blue-100">
                <Quote size={32} />
              </div>
              
              <div className="flex items-center space-x-4 mb-6">
                <img
                  src={review.image}
                  alt={review.name}
                  className="w-16 h-16 rounded-full object-cover border-2 border-blue-100"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">{review.name}</h4>
                  <p className="text-blue-600 font-medium">{review.role}</p>
                  <p className="text-gray-600 text-sm">{review.company}</p>
                </div>
              </div>

              <div className="flex items-center space-x-1 mb-4">
                {renderStars(review.rating)}
              </div>

              <p className="text-gray-700 leading-relaxed italic">
                "{review.text}"
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Ready to Join Our Success Stories?</h3>
            <p className="text-gray-600 mb-6">
              Let's discuss how we can help transform your business and achieve exceptional results.
            </p>
            <button className="bg-blue-600 text-white px-8 py-4 rounded-full hover:bg-blue-700 transition-colors duration-200 font-medium">
              Schedule a Consultation
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Reviews;
