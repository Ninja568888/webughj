
import React from 'react';
import { Award, Clock, MapPin, Target } from 'lucide-react';

const About = () => {
  const stats = [
    { icon: Award, value: "2000", label: "Established Year" },
    { icon: MapPin, value: "4000", label: "Sq. Ft. Showroom" },
    { icon: Target, value: "4500", label: "Sq. Yard Warehouse" },
    { icon: Clock, value: "23+", label: "Years Experience" }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                About <span className="text-blue-600">Maheswari Enterprises</span>
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed mb-6">
                Established in the year 2000, Maheswari Enterprises is a renowned manufacturer and dealer in C.I & D.I 
                Casting and Iron & Steel products. Located at the prestigious Six Point Saraswati Park Junction, 
                Dabagardens in the heart of Visakhapatnam city.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Managed by Mr. Ansul Singhi with a team of experienced executives and agents, we have built a healthy 
                bridge between manufacturers and consumers with over twelve years of market experience. We are the 
                biggest distributor of casting products in coastal Andhra Pradesh.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Strategic Location</h4>
                  <p className="text-gray-600">Exclusively located at Six Point Saraswati Park Junction with Sales Office in Kolkata.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Extensive Network</h4>
                  <p className="text-gray-600">Long-standing connections with renowned suppliers and large base of satisfied customers.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Future Expansion</h4>
                  <p className="text-gray-600">Ambitious plans for expansion in C.I & D.I Castings and modern water management solutions.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 text-center shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="text-blue-600" size={32} />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
